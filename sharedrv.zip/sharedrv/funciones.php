<?php

require __DIR__ . '/driveapi/vendor/autoload.php';
putenv('GOOGLE_APPLICATION_CREDENTIALS='. __DIR__ .'/concerts-1610715674631-0b004eb0226b.json');


function GetFileID($codigo_carpeta)
{
    
    try{
        $client = new Google_Client();
        $client->useApplicationDefaultCredentials();
        $client->setScopes(['https://www.googleapis.com/auth/drive.file','https://www.googleapis.com/auth/drive']);

        $service = new Google_Service_Drive($client);
        //carpeta stream (parent)
        $folderId = '1qsygoOh-CBcEdM0QI1RpgtpvQFxMFJG0';
        $optParams = array(
            'fields' => "files(id)",
            'q' => "'".$folderId."' in parents and name='".$codigo_carpeta."'"
            );
        $results = $service->files->listFiles($optParams);
        if (count($results) > 0)
        {
            return $results[0]->id;
        }
        return 0;
        
        
    } catch(Exception $e)
    {
        return 0;
    }
        
}


function compartir($codigo,$user_email)
{
    
    try{
        $client = new Google_Client();
        $client->useApplicationDefaultCredentials();
        $client->setScopes(['https://www.googleapis.com/auth/drive.file','https://www.googleapis.com/auth/drive']);

        $service = new Google_Service_Drive($client);
        //carpeta stream (parent)
        $folderId = '1qsygoOh-CBcEdM0QI1RpgtpvQFxMFJG0';
        $optParams = array(
            'fields' => "files(id)",
            'q' => "'".$folderId."' in parents and name='".$codigo."'"
            );
        $results = $service->files->listFiles($optParams);
        if (count($results) > 0)
        {
            $fileId = $results[0]->id;
            $newPermission = new Google_Service_Drive_Permission(array(
                'type' => 'user',
                'role' => 'reader',
                'emailAddress' => $user_email
            ));
            $created =  $service->permissions->create($fileId, $newPermission); 
            $permissionsId = $created->id;
            guardar_permiso($permissionsId,$fileId,$user_email);
            return 1;
        }
        else{
            return 0;
        }
    } catch(Exception $e)
    {
        return 0;
    }
        
}

function compartir_xid($id_archivo,$user_email)
{
    
    try{
        $client = new Google_Client();
        $client->useApplicationDefaultCredentials();
        $client->setScopes(['https://www.googleapis.com/auth/drive.file','https://www.googleapis.com/auth/drive']);

        $service = new Google_Service_Drive($client);
        $fileId = $id_archivo;
        $newPermission = new Google_Service_Drive_Permission(array(
                'type' => 'user',
                'role' => 'reader',
                'emailAddress' => $user_email
        ));
        $created =  $service->permissions->create($fileId, $newPermission); 
        $permissionsId = $created->id;
        guardar_permiso($permissionsId,$fileId,$user_email);
        return 1;
        
    } catch(Exception $e)
    {
        return 0;
    }
        
}

function borrar_permiso($archivo_id,$permiso_id)
{
    
    try{
        $client = new Google_Client();
        $client->useApplicationDefaultCredentials();
        $client->setScopes(['https://www.googleapis.com/auth/drive.file','https://www.googleapis.com/auth/drive']);

        $service = new Google_Service_Drive($client);
        $deleted = $service->permissions->delete($archivo_id, $permiso_id);
        return 1;
        
    } catch(Exception $e)
    {
        return 0;
    }
        
}

function batch_borrado_permisos()
{
    $host = '127.0.0.1';
    $db   = 'sharedrv';
    $user = 'root';
    $pass = '';
    $port = "3306";
    //$charset = 'latin1_swedish';

    $options = [
        \PDO::ATTR_ERRMODE            => \PDO::ERRMODE_EXCEPTION,
        \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
        \PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $dsn = "mysql:host=$host;dbname=$db;port=$port";
    $fecha_momento = new DateTime('NOW');
    $fecha_momento = $fecha_momento->format('Y-m-d');
    $borrados = 0;
    try{
        $pdo = new \PDO($dsn, $user, $pass, $options);
        $stmt = $pdo->prepare("SELECT * FROM permisos WHERE estado=:estado");
        $stmt->execute(['estado' => 'A']); 
        $data = $stmt->fetchAll();
        foreach ($data as $row) {

            $fecha_temp = new DateTime($row['fecha_creacion']);
            $fecha_temp = $fecha_temp->add(new DateInterval('P3D'));
            $fecha_temp = $fecha_temp->format('Y-m-d');

            //si se llega a los 3 de limite o los supera
            if ( $fecha_momento >= $fecha_temp )
            {
                $res = borrar_permiso($row['id_archivo'],$row['id_permiso']);
                if($res == 1)
                {

                    $pdo_temp = new \PDO($dsn, $user, $pass, $options);
                    $sql = "UPDATE permisos SET estado=? WHERE id_archivo=? AND id_permiso=? AND correo=?";
                    $stmt= $pdo_temp->prepare($sql);
                    $stmt->execute(['D', $row['id_archivo'], $row['id_permiso'], $row['correo']]);
                    $borrados++;
                }

            }


        }
        

    } catch (\PDOException $e) {
        if ($pdo->inTransaction())
        {
            $pdo->rollback();
        }
        
    //    throw new \PDOException($e->getMessage(), (int)$e->getCode());
  
    }
    return $borrados;
}

function guardar_permiso($permid, $fid,$correo)
{
    $host = '127.0.0.1';
    $db   = 'sharedrv';
    $user = 'root';
    $pass = '';
    $port = "3306";
    //$charset = 'latin1_swedish';

    $options = [
        \PDO::ATTR_ERRMODE            => \PDO::ERRMODE_EXCEPTION,
        \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
        \PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $dsn = "mysql:host=$host;dbname=$db;port=$port";
    try{
        $pdo = new \PDO($dsn, $user, $pass, $options);
        $fecha_now = new DateTime('NOW');
        $sql = "INSERT INTO permisos (id_permiso, fecha_creacion, id_archivo, correo, estado) VALUES (?,?,?,?,?)";
        $stmt= $pdo->prepare($sql);
        $stmt->execute([$permid, strval($fecha_now->format('Y-m-d')), $fid,$correo,"A"]);

    } catch (\PDOException $e) {
        if ($pdo->inTransaction())
        {
            $pdo->rollback();
        }
        
    //    throw new \PDOException($e->getMessage(), (int)$e->getCode());
  
    }
}


?>

